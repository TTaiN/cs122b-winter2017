-- CS 122B Group 42 (Project 3, Task 5) ---

Important Notes:
	-> If you plan to connect our AWS DB, please run the program directly on the AWS instance!
		-> The default DB credentials are set to localhost, testuser, testpass, moviedb. (Editable in DatabaseHelper.java)
		-> If you run the program connecting remotely to AWS DB, it will be slow due to network insertion.
			-> Running it locally takes less than a minute, both for parsing and DB insertion!

AWS DB Instance Information:
	-> This is configurable in DatabaseHelper.java
	*IP = 35.167.240.26
	*DB = moviedb
	*USER = testuser
	*PW = testpass
	-> User - cs122b, PW - cs122group42 also exists if the above does not work.

Design Decisions:
	-> Parse Method: SAX
	
	-> Main.xml
		-> This .xml file was used to populate movies, genres, and movies_in_genres
		-> If year is misformatted or does not exist, the entry is skipped.
		-> The list of directors must be less than or equal to 100 characters due to the
			databases limit on the director attribute. If the list of directors exceeds
			100 characters, the entry is skipped.
		-> Genre titles were not modified and were added to database as they were written
			in the .xml file. For example, rom was not changed to romance.
		-> All duplicates are skipped.
	-> Actors.xml
		-> If a Star does not have a non-null first AND/OR last name, it is skipped completely, since the DB requires both first_name & last_name NOT NULL.
			-> So a Star with a Stage Name, but no first and/or last name, is skipped.
		-> A year is stripped of all non-numerical characters, then tested if it is a valid integer. If not, set to NULL.
		-> Stage, first & last names are stripped of all non-alphabetical characters, excluding . ~ : characters.
		-> All duplicates are also skipped.
	-> Casts.xml
		-> ***Important to note: Casts only contain stage names, NOT first/last name.***
			-> If a first/last name for the Stage Name is not found in Actors.xml or the database, do not add it to stars_in_movies.
				-> This is done using a HashMap<StageName, StarInfo> using entries from the XML files AND database.
		
Design Optimizations:
	-> Use AutoCommit(false) & commit();
	-> Use Batch Insert, executing batches of 1000 at a time.
	-> Pull all required data from the database first and store them into HashMap to reduce # of queries overall.
		-> Note: This helps a lot when we are searching for duplicates and saves time. We pull all the necessary info first.

How to compile:
	Make new project and include all sources.
	Add ./lib/mysql-connector.jar to your Java build path for SQL connections. Also include SAX parser library if your Java does not have them automatically.
	Build & run. You can build/run directly from .class or export as Runnable JAR. Ensure all *.xml files are in the project working directory.

How to run:
	-> ENSURE THAT THE *.xml FILES ARE IN THE WORKING DIRECTORY!
	Once the project is setup, if exported/compiled into runnable JAR, simply run the jar with no arguments. Main class should be the default run class.
		-> You can do command "java -jar ExportedRunnableJar.jar", for example.
	If you compiled/exported and have individual class files, run Main.class with no arguments, with the other .classes in same working directory.
		-> You can do command "java -cp . Main.class" or "java -cp . Main" or something of the sort.